// Omer Arad 314096389

import biuoop.GUI;
import game.GameFlow;
import game.animation.AnimationRunner;
import game.levels.Level1;
import game.levels.Level2;
import game.levels.Level3;
import game.levels.Level4;
import interfaces.LevelInformation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * This class has a main method that creates a game, initializes, and runs it.
 */
public class Ass6Game {
    public static final int WIDTH = 800;  // Width of window
    public static final int HEIGHT = 600; // Height of window
    private static final String TITLE = "Arkanoid"; // Window title

    /**
     * Create a game, initialize, and run it.
     * @param args no arguments
     */
    public static void main(String[] args) {
        LevelInformation levelInformation = new Level2();
        List<LevelInformation> levels = new ArrayList<>();
        GUI gui = new GUI(TITLE, WIDTH, HEIGHT);
        GameFlow gameFlow = new GameFlow(new AnimationRunner(gui), gui.getKeyboardSensor());

        // add levels to the levels list.
        addLevels(args, levels);

        gameFlow.runLevels(levels);
        gui.close();
    }

    /**
     * This function adds the levels to the level list.
     * If no levels where given then add levels 1-4.
     * @param args args
     * @param levels list of levels
     */
    private static void addLevels(String[] args, List<LevelInformation> levels) {
        if (args.length == 0 || Objects.equals(args[0], "${args}")) {
            levels.add(new Level1());
            levels.add(new Level2());
            levels.add(new Level3());
            levels.add(new Level4());
        } else {
            for (String arg : args) {
                switch (arg) {
                    case "1":
                        levels.add(new Level1());
                        break;
                    case "2":
                        levels.add(new Level2());
                        break;
                    case "3":
                        levels.add(new Level3());
                        break;
                    case "4":
                        levels.add(new Level4());
                        break;
                    default:
                }
            }
        }
    }
}
