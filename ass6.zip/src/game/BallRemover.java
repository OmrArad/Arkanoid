package game;

import gui.sprites.Ball;
import gui.sprites.Block;
import interfaces.HitListener;

/**
 * This class defines a BallRemover which holds a reference to the game and the amount of remaining balls,
 * and is in charge of the removing balls from the game.
 */
public class BallRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBalls;

    /**
     * This is the constructor method.
     * @param gameLevel reference to the Game object
     * @param remainingBalls how many balls remain
     */
    public BallRemover(GameLevel gameLevel, Counter remainingBalls) {
        this.gameLevel = gameLevel;
        this.remainingBalls = gameLevel.getRemainingBalls();
    }

    // Balls that hit the "death region" (bottom of screen)
    // are removed from the game. Remember to remove this listener from the ball
    // that is being removed from the game.
    @Override
    public void hitEvent(Block deathBlock, Ball hitter) {
        hitter.removeFromGame(gameLevel);
        remainingBalls.decrease(1);
    }
}
