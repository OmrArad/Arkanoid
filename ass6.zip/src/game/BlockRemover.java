package game;

import gui.sprites.Ball;
import gui.sprites.Block;
import interfaces.HitListener;

/**
 * This class defines a BlockRemover which is in charge of removing blocks from the game,
 * as well as keeping count of the number of blocks that remain.
 */
public class BlockRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBlocks;

    /**
     * This is the constructor method.
     * @param gameLevel reference to the Game object
     * @param removedBlocks how many blocks have been removed
     */
    public BlockRemover(GameLevel gameLevel, Counter removedBlocks) {
        this.gameLevel = gameLevel;
        this.remainingBlocks = gameLevel.getRemainingBlocks();
    }

    // Blocks that are hit should be removed
    // from the game. Remember to remove this listener from the block
    // that is being removed from the game.
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.removeHitListener(this);
        beingHit.removeFromGame(gameLevel);
        remainingBlocks.decrease(1);
        hitter.getGameEnvironment().removeCollidable(beingHit);
    }
}