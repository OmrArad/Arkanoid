package game;

import gui.shapes.Point;
import interfaces.Collidable;
/**
 * This class defines the object CollisionInfo (which holds the point and object of collision).
 */
public class CollisionInfo {

    private Point collisionPoint;
    private Collidable collisionObject;

    /**
     * This is the constructor method.
     * It defines a CollitionInfo object using given collision point and collidable object.
     * @param collisionPoint point of collision.
     * @param collisionObject collidable object involved in collision.
     */
    public CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionPoint = collisionPoint;
        this.collisionObject = collisionObject;
    }

    /**
     * this method returns the point at which the collision occurs.
     * @return point of collision
     */
    public Point collisionPoint() {
        return this.collisionPoint;
    }

    /**
     * this method returns the collidable object involved in the collision.
     * @return collidable object.
     */
    public Collidable collisionObject() {
        return this.collisionObject;
    }
}
