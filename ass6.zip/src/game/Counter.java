package game;

/**
 * This class defines a simple Counter, and related methods.
 */
public class Counter {
    private int count;

    /**
     * This is the constructor method.
     * It sets the value of count to 0.
     */
    public Counter() {
        this.count = 0;
    }

    /**
     * This is another constructor method,
     * that sets the value of count to given count.
     * @param count count
     */
    public Counter(int count) {
        this.count = count;
    }

    /**
     * add number to current count.
     * @param number number
     */
    void increase(int number) {
        count += number;
    }

    /**
     * subtract number from current count.
     * @param number number
     */
    void decrease(int number) {
        count -= number;
    }

    /**
     * get current count.
     * @return count
     */
    int getValue() {
        return count;
    }

    /**
     * public method to get current count.
     * @return count
     */
    public int getCount() {
        return count;
    }
}
