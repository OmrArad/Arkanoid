package game;

import biuoop.DrawSurface;
import interfaces.Animation;

/**
 * This class defines a EndScreen which implements Animation,
 * and is in charge of creating and showing the end screen.
 */
public class EndScreen implements Animation {
    private boolean stop;
    private String string;

    /**
     * This is the constructor method.
     * @param string string to print in end screen.
     */
    public EndScreen(String string) {
        this.stop = false;
        this.string = string;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, string, 40);
    }

    @Override
    public boolean shouldStop() {
        return this.stop;
    }

    @Override
    public int getMillisecondsPerFrame() {
        return 1000 / 60;
    }
}