package game;

import java.util.ArrayList;
import java.util.List;
import interfaces.Collidable;
import gui.shapes.Line;
import gui.shapes.Point;

/**
 * This class defines a game environment as well as and other related methods.
 */
public class GameEnvironment {

    private List<Collidable> collidableList;

    /**
     * this method is the constructor. It creates a game environment and an empty list of collidables.
     */
    public GameEnvironment() {
        this.collidableList = new ArrayList<>();
    }

    /**
     * Return the list of all collidables in this game environment (might be empty).
     * @return list of collidables
     */
    public List<Collidable> getCollidableList() {
        return this.collidableList;
    }

    /**
     * This method gets a collidable and adds it to the game environment.
     * @param c collidable
     */
    public void addCollidable(Collidable c) {
        this.collidableList.add(c);
    }

    /**
     * This method gets a collidable and removes it from the game environment.
     * @param c collidable
     */
    public void removeCollidable(Collidable c) {
        this.collidableList.remove(c);
    }

    /**
     * This method gets a trajectory(line) and is in charge of finding the closest (to start of line) collision,
     * with an object travelling on this trajectory from start to end.
     * @param trajectory line representing the trajectory of an object moving from start to end of trajectory.
     * @return The information about the closest collision, or null if no collisions will occur.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        List<CollisionInfo> intersectionInfo = new ArrayList<CollisionInfo>();
        // Make a copy of the Collidables before iterating over them.
        List<Collidable> collidables = new ArrayList<Collidable>(this.collidableList);

        // for each collidable in list, add closest intersection to the start of the trajectory (if exists)
        for (Collidable c : collidables) {
            Point p = trajectory.closestIntersectionToStartOfLine(c.getCollisionRectangle());
            if (p != null) {
                CollisionInfo collisionInfo = new CollisionInfo(p, c);
                intersectionInfo.add(collisionInfo);
            }
        }

        // return null if no collisions exists.
        // otherwise, find the closest collision
        // to the start of the line and return it.
        if (intersectionInfo.isEmpty()) {
            return null;
        } else {
            CollisionInfo toReturn = intersectionInfo.get(0); // set first element to be returned
            double min = trajectory.start().distance(toReturn.collisionPoint());

            // find the closest collision that is going to occur
            for (CollisionInfo collisionInfo : intersectionInfo) {
                double dist = trajectory.start().distance(collisionInfo.collisionPoint());
                if (dist < min) {
                    min = dist;
                    toReturn = collisionInfo;
                }
            }

            return toReturn;
        }

    }

}
