package game;

import biuoop.KeyboardSensor;
import game.animation.AnimationRunner;
import game.animation.KeyPressStoppableAnimation;
import interfaces.LevelInformation;

import java.util.List;

/**
 * This class defines a GameFlow which will be in charge of creating the different levels,
 * and moving from one level to the next.
 */
public class GameFlow {
    private static final int LEVEL_CLEAR = 100;

    private AnimationRunner animationRunner;
    private KeyboardSensor keyboardSensor;
    private Counter score;

    /**
     * The constructor method.
     *
     * @param ar animation runner.
     * @param ks keyboard sensor.
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks) {
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.score = new Counter();
    }

    /**
     * Run the levels given as parameter.
     * @param levels list of levels.
     */
    public void runLevels(List<LevelInformation> levels) {
        boolean lost = false;
        for (LevelInformation levelInfo : levels) {

            GameLevel level = new GameLevel(levelInfo,
                    this.keyboardSensor,
                    this.animationRunner,
                    this.score);

            level.initialize();

            while (level.getRemainingBlocks().getValue() != 0 && level.getRemainingBalls().getValue() != 0) {
                level.run();
            }

            if (level.getRemainingBalls().getValue() == 0) {
                this.animationRunner.run(
                        new KeyPressStoppableAnimation(this.keyboardSensor, this.keyboardSensor.SPACE_KEY,
                                new EndScreen("Game Over. Your score is " + this.score.getValue())));
                lost = true;
                break;
            }
            this.score.increase(LEVEL_CLEAR);
        }
        if (!lost) {
            this.animationRunner.run(
                    new KeyPressStoppableAnimation(this.keyboardSensor, this.keyboardSensor.SPACE_KEY,
                            new EndScreen("You Win! Your score is " + this.score.getValue())));
        }
    }
}

