package game;

import biuoop.DrawSurface;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import biuoop.KeyboardSensor;
import game.animation.AnimationRunner;
import game.animation.CountdownAnimation;
import game.animation.KeyPressStoppableAnimation;
import game.listeners.PrintingHitListener;
import gui.Velocity;
import gui.sprites.ScoreIndicator;
import interfaces.Animation;
import interfaces.Collidable;
import interfaces.LevelInformation;
import interfaces.Sprite;
import gui.shapes.Rectangle;
import gui.shapes.Point;
import gui.sprites.Ball;
import gui.sprites.Paddle;
import gui.sprites.Block;



/**
 * This class defines a Game which holds the sprites and the collidables, and is in charge of the animation.
 */
public class GameLevel implements Animation {

    public static final int WIDTH = 800;  // Width of window
    public static final int HEIGHT = 600; // Height of window
    public static final int BLOCK_WIDTH = 50;
    public static final int BLOCK_HEIGHT = 20;
    public static final int SIDE_BLOCK_HEIGHT = 600;
    public static final int SIDE_BLOCK_WIDTH = 20;
    public static final int TOP_BOTTOM_BLOCK_HEIGHT = 20;
    private static final int SCORE_INDICATOR_HEIGHT = 15;
    private static final int RADIUS = 5;  // Size of ball

    private AnimationRunner runner;
    private boolean running;
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private List<Collidable> collidables;
    private Counter remainingBlocks;
    private Counter remainingBalls;
    private Counter score;
    private KeyboardSensor keyboard;
    private LevelInformation levelInformation;

    /**
     * This is the constructor method.
     * It creates a game with a collection of sprites, collidables, and a new game environment,
     * using the given levelInformation, keyboard sensor, animation runner, and score.
     * @param levelInformation information about this level.
     * @param keyboard keyboard sensor
     * @param animationRunner animation runner
     * @param score score - track across all levels.
     */
    public GameLevel(LevelInformation levelInformation, KeyboardSensor keyboard, AnimationRunner animationRunner,
                     Counter score) {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.collidables = new ArrayList<Collidable>();
        this.score = score;
        this.runner = animationRunner;
        this.levelInformation = levelInformation;
        this.keyboard = keyboard;
        this.remainingBlocks = new Counter(this.levelInformation.numberOfBlocksToRemove());
        this.remainingBalls = new Counter(this.levelInformation.numberOfBalls());
    }

    /**
     * Add a collidable to a list of collidable objects.
     * @param c collidable.
     */
    public void addCollidable(Collidable c) {
        this.collidables.add(c);
    }

    /**
     * Remove a collidable from a list of collidable objects.
     * @param c collidable
     */
    public void removeCollidable(Collidable c) {
        this.collidables.remove(c);
    }

    /**
     * Add a sprite to a list of sprites.
     * @param s sprite.
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * Remove a sprite from a list of sprites.
     * @param s sprite
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

    /**
     * Return the number of remaining blocks.
     * @return number of remaining blocks.
     */
    public Counter getRemainingBlocks() {
        return remainingBlocks;
    }

    /**
     * Return the number of remaining balls.
     * @return number of remaining balls.
     */
    public Counter getRemainingBalls() {
        return remainingBalls;
    }

    /**
     * Add the border blocks to the game using given upperLeft point of rectangle, width, and height.
     * @param upperLeft point of rectangle
     * @param width of rectangle
     * @param height of rectangle
     * @return new border block
     */
    private Block addBorderBlock(Point upperLeft, int width, int height) {
        Rectangle rectangle = new Rectangle(upperLeft, width, height);
        Block block = new Block(rectangle, Color.GRAY);
        block.addToGame(this);
        return block;
    }

    /**
     * Add a ball to the game using given center, and velocity.
     * @param center center point of ball
     * @param v velocity of ball
     */
    private void addBall(Point center, Velocity v) {
        Ball ball = new Ball(center, RADIUS, Color.WHITE);
        ball.setGameEnvironment(this.environment);
        ball.setVelocity(v);
        ball.addToGame(this);
    }

    /**
     * This method initializes a new game.
     * <p> It creates the Blocks and Ball (and Paddle) and adds then to the game.</p>
     */
    public void initialize() {
        // Create a PrintHitListener
        PrintingHitListener printingHitListener = new PrintingHitListener();
        // Count how many blocks are created (excluding border blocks)
        int createdBlocks = 0;
        // Create a BlockRemover
        BlockRemover blockRemover = new BlockRemover(this, new Counter());
        // Create a BallRemover
        BallRemover ballRemover = new BallRemover(this, new Counter());
        // Create a ScoreTrackingListener
        ScoreTrackingListener scoreTrackingListener = new ScoreTrackingListener(score);

        // Add background to the list of sprites
        this.addSprite(this.levelInformation.getBackground());

        // Add the paddle
        Point paddlePoint =
                new Point((WIDTH - this.levelInformation.paddleWidth()) / 2.0, HEIGHT - 2 * BLOCK_HEIGHT);
        Rectangle paddleRect = new Rectangle(paddlePoint, this.levelInformation.paddleWidth(), BLOCK_HEIGHT);
        Paddle paddle = new Paddle(keyboard, paddleRect, Color.ORANGE, this.levelInformation.paddleSpeed());
        paddle.setGameEnvironment(this.environment);
        paddle.addToGame(this);

        // Border blocks
        Point upper = new Point(0, SCORE_INDICATOR_HEIGHT);
        addBorderBlock(upper, WIDTH, TOP_BOTTOM_BLOCK_HEIGHT);

        Point left = new Point(0, TOP_BOTTOM_BLOCK_HEIGHT + SCORE_INDICATOR_HEIGHT);
        addBorderBlock(left, SIDE_BLOCK_WIDTH, SIDE_BLOCK_HEIGHT);

        Point right = new Point(WIDTH - SIDE_BLOCK_WIDTH, TOP_BOTTOM_BLOCK_HEIGHT + SCORE_INDICATOR_HEIGHT);
        addBorderBlock(right, SIDE_BLOCK_WIDTH, SIDE_BLOCK_HEIGHT);

        Point lower = new Point(0, HEIGHT + 10);
        Block deathBlock = addBorderBlock(lower, WIDTH, TOP_BOTTOM_BLOCK_HEIGHT);
        deathBlock.addHitListener(ballRemover);

        // ScoreIndicator Block
        Rectangle rectangle = new Rectangle(new Point(0, 0), WIDTH, SCORE_INDICATOR_HEIGHT);
        ScoreIndicator scoreIndicator =
                new ScoreIndicator(score, Color.CYAN, rectangle, this.levelInformation.levelName());
        scoreIndicator.addToGame(this);

        // Add the blocks to the game
        for (Block b : this.levelInformation.blocks()) {
            b.addHitListener(printingHitListener);
            b.addHitListener(blockRemover);
            b.addHitListener(scoreTrackingListener);
            b.addToGame(this);
        }

        // Add the balls and associate them with the game environment.
        Point center = new Point(WIDTH / 2.0, paddlePoint.getY() - 10);
        for (Velocity v : this.levelInformation.initialBallVelocities()) {
            addBall(center, v);
        }

        // Add all collidables to the game environment.
        for (Collidable collide: collidables) {
            this.environment.addCollidable(collide);
        }
    }

    /**
     * This method is in charge of running the game - that is, starting the animation loop.
     */
    public void run() {
//        this.initialize();
        this.runner.run(new CountdownAnimation(this.sprites)); // countdown before turn starts.
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.runner.run(this);
    }

    /**
     * Generate random color from mixing red, green and blue.
     * @return new color.
     */
    public static Color randColor() {
        java.util.Random rand = new java.util.Random();
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        return new Color(r, g, b);
    }


    @Override
    public void doOneFrame(DrawSurface d) {
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();

        // check number of blocks before drawing
        if (remainingBlocks.getValue() == 0) {
//            score.increase(LEVEL_CLEAR);
//            gui.close();
            this.running = false;
        } else if (remainingBalls.getValue() == 0) {
//            gui.close();
            this.running = false;
        }

        if (this.keyboard.isPressed("p")) {
            this.runner.run(
                    new KeyPressStoppableAnimation(this.keyboard, this.keyboard.SPACE_KEY, new PauseScreen()));
        }

    }

    @Override
    public boolean shouldStop() {
        return !this.running;
    }

    @Override
    public int getMillisecondsPerFrame() {
        return 1000 / 60;
    }
}