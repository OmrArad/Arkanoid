package game;

import biuoop.DrawSurface;
import interfaces.Animation;

/**
 * This class defines a PauseScreen which implements Animation,
 * and is in charge of creating and showing the pause screen.
 */
public class PauseScreen implements Animation {
    private boolean stop;

    /**
     * This is the constructor method.
     */
    public PauseScreen() {
        this.stop = false;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
    }

    @Override
    public boolean shouldStop() {
        return this.stop;
    }

    @Override
    public int getMillisecondsPerFrame() {
        return 1000 / 60;
    }
}