package game;

import gui.sprites.Ball;
import gui.sprites.Block;
import interfaces.HitListener;

/**
 * This class defines a ScoreTrackingListener that is implementing the HitListener interface,
 * and is in charge of tracking the score.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;

    /**
     * This is the constructor method.
     * @param scoreCounter counter of the score
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * Return the current score.
     * @return currentScore
     */
    public Counter getCurrentScore() {
        return currentScore;
    }

    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
       currentScore.increase(5);
    }
}
