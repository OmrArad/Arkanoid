package game;

import java.util.ArrayList;
import java.util.List;
import biuoop.DrawSurface;
import interfaces.Sprite;

/**
 * This class defines a collection of sprites, as well as other related methods.
 */
public class SpriteCollection {

    private List<Sprite> spriteList = new ArrayList<>();

    /**
     * Add a given sprite to the sprite collection.
     * @param s a given sprite.
     */
    public void addSprite(Sprite s) {
        spriteList.add(s);
    }

    /**
     * Remove a given sprite from the sprite collection.
     * @param s a given sprite
     */
    public void removeSprite(Sprite s) {
        spriteList.remove(s);
    }

    /**
     * Call timePassed on all sprites.
     */
    public void notifyAllTimePassed() {
        // Make a copy of the Sprites before iterating over them.
        List<Sprite> sprites = new ArrayList<Sprite>(this.spriteList);
        // Call timePassed on all sprites.
        for (Sprite s : sprites) {
            s.timePassed();
        }
    }

    /**
     * Call drawOn(d) on all sprites.
     * @param d the DrawSurface upon which to draw all sprites.
     */
    public void drawAllOn(DrawSurface d) {
        // Make a copy of the Sprites before iterating over them.
        List<Sprite> sprites = new ArrayList<Sprite>(this.spriteList);
        // Call drawOn(d) on all sprites.
        for (Sprite s: sprites) {
            s.drawOn(d);
        }
    }
}