package game.animation;

import biuoop.DrawSurface;
import biuoop.GUI;
import interfaces.Animation;

/**
 * This class defines the AnimationRunner which is in charge of running animations.
 */
public class AnimationRunner {
    private static final int FRAMES_PER_SECOND = 60;

    private GUI gui;
    private int framesPerSecond;
    private biuoop.Sleeper sleeper;

    /**
     * The constructor method.
     *
     * @param gui the graphic user interface
     */
    public AnimationRunner(GUI gui) {
        this.gui = gui;
        this.framesPerSecond = FRAMES_PER_SECOND;
        this.sleeper = new biuoop.Sleeper();
    }

    /**
     * Run the given animation.
     * @param animation animation to run.
     */
    public void run(Animation animation) {
        int millisecondsPerFrame = animation.getMillisecondsPerFrame();
//                (int) (1000 / this.framesPerSecond);

        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = gui.getDrawSurface();

            animation.doOneFrame(d);

            gui.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                this.sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}
