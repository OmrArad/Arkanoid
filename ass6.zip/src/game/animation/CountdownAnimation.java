package game.animation;

import biuoop.DrawSurface;
import game.SpriteCollection;
import interfaces.Animation;

/**
 * This class defines the CountdownAnimation which implements Animation.
 * The CountdownAnimation will display the given gameScreen,
 * for numOfSeconds seconds, and on top of them it will show
 * a countdown from countFrom back to 1, where each number will
 * appear on the screen for (numOfSeconds / countFrom) seconds, before
 * it is replaced with the next one.
 */
public class CountdownAnimation implements Animation {
    private static final double NUM_OF_SECONDS = 2;
    private static final int COUNT_FROM = 3;
    private double numOfSeconds;
    private int countFrom;
    private SpriteCollection gameScreen;
    private boolean stop;

    /**
     * This is the constructor method. It creates a CountdownAnimation object using final
     * number of seconds (to count down), integer to start countdown from, and the given game screen,
     * to be displayed in background.
     * @param gameScreen screen of current game.
     */
    public CountdownAnimation(SpriteCollection gameScreen) {
        this.numOfSeconds = NUM_OF_SECONDS;
        this.countFrom = COUNT_FROM;
        this.gameScreen = gameScreen;
        this.stop = false;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        this.gameScreen.drawAllOn(d);
        d.drawText(d.getWidth() / 2, d.getHeight() / 2, "" + this.countFrom, 32);
        this.countFrom--;
        if (this.countFrom == 0) {
            this.stop = true;
        }
    }

    @Override
    public boolean shouldStop() {
        return  this.stop;
    }

    @Override
    public int getMillisecondsPerFrame() {
        return (int) (numOfSeconds * 1000) / countFrom;
    }
}
