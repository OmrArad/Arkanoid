package game.levels;

import game.GameLevel;
import gui.Velocity;
import gui.shapes.Point;
import gui.shapes.Rectangle;
import gui.sprites.Background;
import gui.sprites.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * This class defines the first level and implements LevelInformation.
 */
public class Level1 implements LevelInformation {
    private Background background;

    /**
     * This is the constructor method.
     */
    public Level1() {
        this.background = new Background(Color.BLACK);
    }

    @Override
    public int numberOfBalls() {
        return initialBallVelocities().size();
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocities = new ArrayList<>();
        velocities.add(Velocity.fromAngleAndSpeed(180, 8));
        return velocities;
    }

    @Override
    public int paddleSpeed() {
        return 10;
    }

    @Override
    public int paddleWidth() {
        return 90;
    }

    @Override
    public String levelName() {
        return "Direct Hit";
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blocks = new ArrayList<>();
        Point p = new Point((GameLevel.WIDTH / 2.0 - 15), (int) (GameLevel.HEIGHT * 0.3));
        Rectangle r = new Rectangle(p, 30, 30);
        Block b = new Block(r, Color.RED);
        blocks.add(b);
        return blocks;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return blocks().size();
    }
}
