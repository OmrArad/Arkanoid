package game.levels;

import game.GameLevel;
import gui.Velocity;
import gui.shapes.Rectangle;
import gui.sprites.Background;
import gui.sprites.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * This class defines the second level and implements LevelInformation.
 */
public class Level2 implements LevelInformation {
    private Background background;

    /**
     * This method is the constructor method.
     */
    public Level2() {
        this.background = new Background(Color.WHITE);
    }

    @Override
    public int numberOfBalls() {
        return initialBallVelocities().size();
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocities = new ArrayList<>();
        int angle = 135;
        int speed = 7;
        for (int i = 0; i < 10; i++) {
            velocities.add(Velocity.fromAngleAndSpeed(angle, speed));
            angle += 10;
        }

        return velocities;
    }

    @Override
    public int paddleSpeed() {
        return 3;
    }

    @Override
    public int paddleWidth() {
        return (int) (GameLevel.WIDTH * 0.8);
    }

    @Override
    public String levelName() {
        return "Wide Easy";
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blocks = new ArrayList<>();
        double x = GameLevel.SIDE_BLOCK_WIDTH, y = 200;
        double blockWidth = (GameLevel.WIDTH - 2 * GameLevel.SIDE_BLOCK_WIDTH) / 15.0;
        for (int i = 0; i < 15; i++) {
            Color color = GameLevel.randColor();
            for (int j = 0; j < 1; j++) {
                x = createBlock(blocks, x, y, blockWidth, color);
            }
        }
        return blocks;
    }

    /**
     * This function creates a block and adds it to the list of blocks.
     * @param blocks list of blocks.
     * @param x upperLeft x value of block.
     * @param y upperLeft y value of block.
     * @param blockWidth block width.
     * @param color color of block.
     * @return next x value for the next block.
     */
    static double createBlock(List<Block> blocks, double x, double y, double blockWidth, Color color) {
        gui.shapes.Point p = new gui.shapes.Point(x, y);
        Rectangle r = new Rectangle(p, blockWidth, GameLevel.BLOCK_HEIGHT);
        Block b = new Block(r, color);
        blocks.add(b);
        x += blockWidth;
        return x;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return blocks().size();
    }
}
