package game.levels;

import game.GameLevel;
import gui.Velocity;
import gui.shapes.Rectangle;
import gui.sprites.Background;
import gui.sprites.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * This class defines the third level and implements LevelInformation.
 */
public class Level3 implements LevelInformation {
    private static final int BLOCK_START_X = 180;
    private static final int BLOCK_START_Y = 100;
    private static final int BLOCKS_IN_ROW = 12;

    private Background background;

    /**
     * This is the constructor method.
     */
    public Level3() {
        this.background = new Background(new Color((float) 0.2, (float) 0.6, (float) 0.2));
    }

    @Override
    public int numberOfBalls() {
        return initialBallVelocities().size();
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocities = new ArrayList<>();
        int angle = 135;
        int speed = 6;
        for (int i = 0; i < 2; i++) {
            velocities.add(Velocity.fromAngleAndSpeed(angle, speed));
            angle += 90;
        }

        return velocities;
    }

    @Override
    public int paddleSpeed() {
        return 15;
    }

    @Override
    public int paddleWidth() {
        return GameLevel.BLOCK_WIDTH + 40;
    }

    @Override
    public String levelName() {
        return "Green 3";
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blocks = new ArrayList<>();

        // Add the blocks in a nice pattern.
        // First row: add 12 blocks, then add one less each row.
        int x = BLOCK_START_X, y = BLOCK_START_Y;
        for (int i = 0; i < 6; i++) {
            Color color = GameLevel.randColor();
            for (int j = 0; j < BLOCKS_IN_ROW - i; j++) {
                gui.shapes.Point p = new gui.shapes.Point(x, y);
                gui.shapes.Rectangle r = new Rectangle(p, GameLevel.BLOCK_WIDTH, GameLevel.BLOCK_HEIGHT);
                Block b = new Block(r, color);
                blocks.add(b);
                x += GameLevel.BLOCK_WIDTH;
            }
            x = BLOCK_START_X + GameLevel.BLOCK_WIDTH * (i + 1);
            y += GameLevel.BLOCK_HEIGHT;
        }
        return blocks;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return blocks().size();
    }
}
