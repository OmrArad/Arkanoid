package game.levels;

import game.GameLevel;
import gui.Velocity;
import gui.sprites.Background;
import gui.sprites.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * This class defines the forth level and implements LevelInformation.
 */
public class Level4 implements LevelInformation {
    private Background background;

    /**
     * This is the constructor method.
     */
    public Level4() {
        this.background = new Background(Color.CYAN);
    }

    @Override
    public int numberOfBalls() {
        return initialBallVelocities().size();
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocities = new ArrayList<>();
        int angle = 135;
        int speed = 6;
        for (int i = 0; i < 3; i++) {
            velocities.add(Velocity.fromAngleAndSpeed(angle, speed));
            angle += 45;
        }

        return velocities;
    }

    @Override
    public int paddleSpeed() {
        return 7;
    }

    @Override
    public int paddleWidth() {
        return GameLevel.BLOCK_WIDTH + 50;
    }

    @Override
    public String levelName() {
        return "Final Four";
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blocks = new ArrayList<>();
        // Add the blocks in a nice pattern.
        // First row: add 12 blocks, then add one less each row.
        double y = 100;
        double blockWidth = (GameLevel.WIDTH - 2 * GameLevel.SIDE_BLOCK_WIDTH) / 15.0;
        for (int i = 0; i < 7; i++) {
            double x = GameLevel.SIDE_BLOCK_WIDTH;
            Color color = GameLevel.randColor();
            for (int j = 0; j < 15; j++) {
                x = Level2.createBlock(blocks, x, y, blockWidth, color);
            }
            y += GameLevel.BLOCK_HEIGHT;
        }
        return blocks;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return blocks().size();
    }
}
