package game.listeners;

import gui.sprites.Ball;
import gui.sprites.Block;
import interfaces.HitListener;

/**
 * This class defines a PrintingHitListener which implements HitListener,
 * and is in charge of printing a message every time a block is being hit.
 */
public class PrintingHitListener implements HitListener {
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        System.out.println("A Block was hit.");
    }
}
