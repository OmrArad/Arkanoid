package gui;
import gui.shapes.Point;
/**
 * This class defines velocity and related methods.
 * Velocity specifies the change in position on the `x` and the `y` axes.
 */
public class Velocity {
    private double dx;
    private double dy;

    /**
     * This method is the constructor of this class.
     * It creates a new velocity object using given dx and dy.
     * @param dx change in position on the x axis.
     * @param dy change in position on the y axis.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * This method creates a new velocity object using given angle and speed.
     * @param angle direction of movement (degrees).
     * @param speed number of units the ball moves in the given angle.
     * @return new velocity object created using found dx and dy.
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        // Find dx,dy by calculating sin/cos of angle and multiplying by speed.
        double dx = Math.sin(Math.toRadians(angle)) * speed;
        double dy = Math.cos(Math.toRadians(angle)) * speed;
        return new Velocity(dx, dy); // Return velocity using constructor
    }

    /**
     * Get the change in position on the 'x' axis.
     * @return dx value of velocity
     */
    public double getDx() {
        return this.dx;
    }

    /**
     * Get the change in position on the 'y' axis.
     * @return dy value of velocity
     */
    public double getDy() {
        return this.dy;
    }

    /**
     * Get the speed of the ball based on change in dx and dy (using Pythagorean theorem).
     * @return square root of (dx^2 + dy^2) - speed of ball (double)
     */
    public double getSpeed() {
        return Math.sqrt(Math.pow(this.dx, 2) + Math.pow(this.dy, 2));
    }

    /**
     * Set change in position on the x-axis to given value.
     * @param dx a change in position on the x-axis.
     */
    public void setDx(double dx) {
        this.dx = dx;
    }

    /**
     * Set change in position on the y-axis to given value.
     * @param dy a change in position on the y-axis.
     */
    public void setDy(double dy) {
        this.dy = dy;
    }

    /**
     * This method takes a point with position (x,y) and return a new point
     * with position (x+dx, y+dy).
     * @param p point with position (x,y).
     * @return new point with position (x+dx, y+dy).
     */
    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }
}

