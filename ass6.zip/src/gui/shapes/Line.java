package gui.shapes;

/**
 * This class defines a line segment and other related methods.
 */
public class Line {
    private static final int VERTICAL = 0;
    private static final int COLLINEAR = 0;
    private static final int CLOCKWISE = 1;
    private static final int COUNTERCLOCKWISE = 2;

    private double x1;
    private double y1;
    private double x2;
    private double y2;

    /**
     * Constructor - create new line segment using the given points.
     * @param start point where the line segment begins.
     * @param end point where the line segment ends.
     */
    public Line(Point start, Point end) {
        this.x1 = start.getX();
        this.y1 = start.getY();
        this.x2 = end.getX();
        this.y2 = end.getY();
    }

    /**
     * Constructor - create new line segment using the given points
     * (x1,y1) and (x2,y2).
     * @param x1 x value of the point where the line segment begins.
     * @param y1 y value of the point where the line segment begins.
     * @param x2 x value of the point where the line segment ends.
     * @param y2 y value of the point where the line segment ends.
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    /**
     * Calculate the length of a line.
     *
     * <p>the distance between two points (x1,y1) and (x2,y2)
     * is the square root of: ((x1-x2)^2 + (y1-y2)^2)
     * @return the distance between two points of the line
     */
    public double length() {
        return Math.sqrt(Math.pow((this.x1 - this.x2), 2)
                + Math.pow((this.y1 - this.y2), 2));
    }

    /**
     * Find middle point of a line.
     * @return the middle point of the line
     */
    public Point middle() {
        return new Point((this.x1 + this.x2) / 2.0,
                (this.y1 + this.y2) / 2.0);
    }

    /**
     * Get the start point of a line.
     * @return the start point of the line
     */
    public Point start() {
        return new Point(this.x1, this.y1);
    }

    /**
     * Get the end point of a line.
     * @return the end point of the line
     */
    public Point end() {
        return new Point(this.x2, this.y2);
    }

    /**
     * Returns and indicator of where the specified point p lies with
     * respect to the line segment from start to end.
     * @param start point where the line segment begins.
     * @param end point where the line segment ends.
     * @param p point to be checked
     * @return 0 if the line and point are collinear,
     *         1 if the orientation is clockwise,
     *         2 if the orientation is counterclockwise.
     */
    public static int orientation(Point start, Point end, Point p) {
        double orient = (p.getX() - start.getX()) * (end.getY() - start.getY())
                - (p.getY() - start.getY()) * (end.getX() - start.getX());
        if (orient == (double) COLLINEAR) {
            // The point is collinear
            return COLLINEAR;
        }
        // clockwise or counterclockwise
        return (orient > COLLINEAR) ? CLOCKWISE : COUNTERCLOCKWISE;
    }

//    /**
//     * Given a line segment and a point the function checks if the
//     * x value of a point lies on the line segment.
//     * @param l line segment
//     * @param x x value of a point (x,y)
//     * @return true if the x value of the point lies on the line segment,
//     *         false otherwise.
//     */
//    public static boolean onSegment(Line l, double x) {
//        return x >= Math.min(l.start().getX(), l.end().getX())
//                && x <= Math.max(l.start().getX(), l.end().getX());
//    }

    /**
     * Given a line segment and a point the function checks if the point
     * lies on the line segment.
     * @param l line segment
     * @param p point (x,y)
     * @return true if the point lies on the line segment, false otherwise.
     */
    public static boolean onSegment(Line l, Point p) {
        double m = getSlope(l);
        double c = getIntercept(l.start(), m);
        double x = p.getX();
        double y = m * x + c;

        // check if point is in between start and end points of line
        boolean isBetween = p.getX() >= Math.min(l.start().getX(), l.end().getX())
                && p.getX() <= Math.max(l.start().getX(), l.end().getX())
                &&
                p.getY() >= Math.min(l.start().getY(), l.end().getY())
                && p.getY() <= Math.max(l.start().getY(), l.end().getY());

        // check if point is on the line
        boolean onLine = y == p.getY();

        // if point is on the line and in between its start and end point, return true,
        // otherwise return false.
        return isBetween && onLine;
    }

    /**
     * Given a point the function checks if the point
     * lies on this line segment.
     * @param p point (x,y)
     * @return true if the point lies on the line segment, false otherwise.
     */
    public boolean onSegment(Point p) {
        p.setX(Math.round(p.getX()));
        p.setY(Math.round(p.getY()));
        return (int) p.getX() >= (int) Math.min(this.start().getX(), this.end().getX())
                && (int) p.getX() <= (int) Math.max(this.start().getX(), this.end().getX())
                &&
                (int) p.getY() >= (int) Math.min(this.start().getY(), this.end().getY())
                && (int) p.getY() <= (int) Math.max(this.start().getY(), this.end().getY());
    }

    /**
     * The method calculates and returns the slope of a given line.
     * That is calculated by the equation (y2 - y1) / (x2 - x1).
     * In case x1 == x2 then the line is vertical on the slope value is 0.
     * @param l line
     * @return 0 if the line is vertical, otherwise result of slope calculation.
     */
    public static double getSlope(Line l) {
        if (l.x1 == l.x2) {
            // The line is vertical
            return VERTICAL;
        }
        return (l.y2 - l.y1) / (l.x2 - l.x1);
    }

    /**
     * Given a point (x,y) and slope (m) the function returns the
     * y-intercept (c value) of the equation y = mx + c.
     *
     * <p>a y-intercept is the point where the graph of a function intersects
     * the y-axis of the coordinate system.
     * As such, these points satisfy x = 0.
     * In this case c = y - mx.
     * @param p point (x,y)
     * @param m slope
     * @return result of the calculation y - mx.
     */
    public static double getIntercept(Point p, double m) {
        return p.getY() - m * p.getX();
    }

    /**
     * This method is in charge of checking that two parallel intersecting
     * lines are not overlapping.
     * @param onSegment this point should be on this (the first) line segment
     * @param pEqual this point should be equal to this onSegment point
     * @param offSeg1 this point should not be on this segment (otherwise
     *                lines are overlapping)
     * @param offSeg2 this point should not be on this segment (otherwise
     *                lines are overlapping)
     * @param other the other line
     * @return true if the lines are not overlapping, false otherwise.
     */
    public boolean notOverlapping(Point onSegment, Point pEqual,
                                  Point offSeg1, Point offSeg2,
                                  Line other) {
        return  (onSegment(this, onSegment)
                && onSegment.equals(pEqual)
                && !onSegment(this, offSeg1)
                && !onSegment(other, offSeg2));
    }

    /**
     * This method checks if two parallel lines are intersecting.
     * @param other the other line
     * @return point if intersection if it exists, null otherwise.
     */
    public Point getParallelIntersect(Line other) {
        Point p1 = this.start();
        Point p2 = this.end();
        Point p3 = other.start();
        Point p4 = other.end();

        if (notOverlapping(p1, p4, p3, p2, other)) {
            return p1;
        } else if (notOverlapping(p2, p3, p4, p1, other)) {
            return p2;
        } else {
            return null;
        }
    }

    /**
     * This method finds the intersection point of two non parallel lines.
     * @param other the other line
     * @param m1 this line's slope
     * @param c1 this line's y-intercept
     * @param m2 other line's slope
     * @param c2 other line's y-intercept
     * @return point of intersection
     */
    public Point findIntersection(Line other, double m1, double c1,
                                  double m2, double c2) {
        double x0;
        double y0;
        if (m1 == VERTICAL
                && this.start().getX() == this.end().getX()) {
            x0 = this.start().getX();
            y0 = m2 * x0 + c2;
        } else if (m2 == VERTICAL
                && other.start().getX() == other.end().getX()) {
            x0 = other.start().getX();
            y0 = m1 * x0 + c1;
        } else {
            x0 = (c2 - c1) / (m1 - m2);
            y0 = m1 * x0 + c1;
        }
        return new Point(x0, y0);
    }

    /**
     * This method checks if two intersecting lines are parallel.
     * in case both slopes equal 0, this method also checks that lines are
     * not perpendicular.
     * @param m1 this line's slope
     * @param m2 other line's slope
     * @param other the other line
     * @return true if lines are parallel, false otherwise.
     */
    public boolean isParallel(double m1, double m2, Line other) {
        return m1 == m2
                && (this.start().getX() != this.end().getX()
                && other.start().getX() != other.end().getX())
                || (this.start().getX() == this.end().getX()
                && other.start().getX() == other.end().getX());
    }

    /**
     * The method checks if two lines intersect.
     * @param other the other line
     * @return true if the lines intersect, false otherwise
     */
    public boolean isIntersecting(Line other) {

        // Find the four orientation needed for general and special cases
        int orient1 = orientation(this.start(), this.end(), other.start());
        int orient2 = orientation(this.start(), this.end(), other.end());
        int orient3 = orientation(other.start(), other.end(), this.start());
        int orient4 = orientation(other.start(), other.end(), this.end());

        if (orient1 != orient2 && orient3 != orient4) {
            // General Case
            return true;
        } else {
            // Special Cases - Lines are collinear
            return (orient1 == COLLINEAR || orient4 == COLLINEAR)
                    && (onSegment(this, other.start()))
                    || ((orient2 == COLLINEAR || orient3 == COLLINEAR)
                    && onSegment(this, other.end()));
        }
    }

    /**
     * The method is in charge of finding where two lines are intersecting.
     * @param other the other line
     * @return the intersection point if the lines intersect,
     *         and null otherwise.
     */
    public Point intersectionWith(Line other) {
        // Find if the two lines are intersecting
        if (this.isIntersecting(other)) {

            /*
            Find the slope (m) and y-intercept (c) of each line,
            as in y = mx + c
            */
            double m1 = getSlope(this);
            double c1 = getIntercept(this.start(), m1);
            double m2 = getSlope(other);
            double c2 = getIntercept(other.start(), m2);

            if (isParallel(m1, m2, other)) {

                /*
                The lines are parallel.
                Find if they have the same start/end point.
                Assuming equal / overlapping lines have no intersection
                */
                return getParallelIntersect(other);
            } else {
                // The lines are not parallel - find intersection
                return findIntersection(other, m1, c1, m2, c2);
            }
        }
        // No intersection
        return null;
    }

    /**
     * The method checks if two lines are equal.
     * @param other the other line
     * @return true if the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        return ((this.start().equals(other.start())
                && this.end().equals(other.end()))
                || (this.start().equals(other.end())
                && this.end().equals(other.start())));
    }

    /**
     * This method gets a rectangle, and returns the closest intersection point to the
     * start of the line. If such point does not exist, the method returns null.
     * @param rect rectangle to check intersection with.
     * @return closest intersection point to the start of the line, or null (no intersection point).
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {

        // create list of intersection points with rectangle.
        java.util.List<Point> pointList = rect.intersectionPoints(this);

        // return null if no intersection points exists.
        // otherwise, find the closest intersection point
        // to the start of the line and return it.
        if (pointList.isEmpty()) {
            return null;
        } else {

            // set min to be distance from first point in list
            // and retPoint to be first point in list.
            double min = this.start().distance(pointList.get(0));
            Point retPoint = pointList.get(0);

            // iterate through list to find closest to start of line
            for (Point point : pointList) {
                double dist = this.start().distance(point);
                if (dist < min) {
                    min = dist;
                    retPoint = point;
                }
            }
            return retPoint;
        }
    }
}
