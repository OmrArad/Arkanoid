package gui.shapes;

/**
 * This class defines a rectangle and other related methods.
 */
public class Rectangle {

    private Point upperLeft;
    private double width;
    private double height;

    /**
     * Constructor - creates a new rectangle with location and width/height.
     * @param upperLeft Upper left point of rectangle.
     * @param width width of rectangle.
     * @param height height of rectangle.
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }

    /**
     * Find all intersection points of this rectangle with a given line,
     * and return a (possibly empty) list of these point.
     * @param line the specified line with which we check if rectangle is intercepting
     * @return list of intersection points.
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        // create list
        java.util.List<Point> pointList = new java.util.ArrayList<Point>();

        // If intersection with upper side of rectangle exists, add intersection point to list.
        Point intersect = line.intersectionWith(this.getUpperSide());
        if (intersect != null) {
            pointList.add(intersect);
        }

        // If intersection with lower side of rectangle exists, add intersection point to list.
        intersect = line.intersectionWith(this.getLowerSide());
        if (intersect != null) {
            pointList.add(intersect);
        }

        // If intersection with right side of rectangle exists, add intersection point to list.
        intersect = line.intersectionWith(this.getRightSide());
        if (intersect != null) {
            pointList.add(intersect);
        }

        // If intersection with left side of rectangle exists, add intersection point to list.
        intersect = line.intersectionWith(this.getLeftSide());
        if (intersect != null) {
            pointList.add(intersect);
        }

        // Return a (possibly empty) list of intersection points between line and this rectangle.
        return pointList;
    }

    /**
     * Return the width of this rectangle.
     * @return this.width
     */
    public double getWidth() {
        return this.width;
    }

    /**
     * Return the height of this rectangle.
     * @return this.height
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * Return the upper left point of rectangle.
     * @return this.upperLeft
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }

    /**
     * Change upper left point of rectangle to the given point.
     * @param upperLeft point
     */
    public void setUpperLeft(Point upperLeft) {
        this.upperLeft = upperLeft;
    }

    /**
     * Calculate and return upper right point of rectangle. (using width and upper left point)
     * @return upper right point of rectangle
     */
    public Point getUpperRight() {
        return new Point(upperLeft.getX() + width, upperLeft.getY());
    }

    /**
     * Calculate and return lower right point of rectangle. (using width, height, and upper left point)
     * @return lower right point of rectangle
     */
    public Point getLowerRight() {
        return new Point(upperLeft.getX() + width, upperLeft.getY() + height);
    }

    /**
     * Calculate and return lower left point of rectangle. (using height and upper left point)
     * @return lower left point of rectangle
     */
    public Point getLowerLeft() {
        return new Point(upperLeft.getX(), upperLeft.getY() + height);
    }

    /**
     * Get the upper side of this rectangle.
     * @return line between upper left and upper right points of rectangle.
     */
    public Line getUpperSide() {
        return new Line(this.upperLeft, this.getUpperRight());
    }

    /**
     * Get the lower side of this rectangle.
     * @return line between lower left and lower right points of rectangle.
     */
    public Line getLowerSide() {
        return new Line(this.getLowerLeft(), this.getLowerRight());
    }

    /**
     * Get the right side of this rectangle.
     * @return line between upper right and lower right points of rectangle.
     */
    public Line getRightSide() {
        return new Line(this.getUpperRight(), this.getLowerRight());
    }

    /**
     * Get the left side of this rectangle.
     * @return line between upper left and lower left points of rectangle.
     */
    public Line getLeftSide() {
        return new Line(this.upperLeft, this.getLowerLeft());
    }

    /**
     * Check if point is inside a rectangle.
     * @param point point
     * @return true if point is inside rectangle borders, false otherwise.
     */
    public boolean isInside(Point point) {
        return point.getX() > this.getUpperLeft().getX()
                && point.getY() < this.getUpperRight().getX()
                && point.getY() > this.getUpperLeft().getY()
                && point.getY() < this.getLowerLeft().getY();
    }
}