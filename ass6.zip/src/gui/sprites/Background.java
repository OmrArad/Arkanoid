package gui.sprites;

import biuoop.DrawSurface;
import game.GameLevel;
import interfaces.Sprite;

import java.awt.Color;

/**
 * This class defines a Background which implements Sprite,
 * and is in charge of creating and drawing the background of the level.
 */
public class Background implements Sprite {
    private Color backgroundColor;

    /**
     * THis method is the constructor.
     * @param background of the gameLevel.
     */
    public Background(Color background) {
        this.backgroundColor = background;
    }

    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.backgroundColor);
        d.fillRectangle(0, 0, GameLevel.WIDTH, GameLevel.HEIGHT);
    }

    @Override
    public void timePassed() {
        // do nothing
    }

    /**
     * This method is in charge of adding the background to the gameLevel (calling addSprite method).
     * @param g gameLevel
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
