package gui.sprites;
import biuoop.DrawSurface;
import interfaces.Sprite;
import gui.shapes.Rectangle;
import game.GameEnvironment;
import game.GameLevel;
import gui.shapes.Point;
import gui.Velocity;
import gui.shapes.Line;
import game.CollisionInfo;
import java.awt.Color;

/**
 * This class defines a ball (which is actually a circle).
 */
public class Ball implements Sprite {
    private Point center;
    private int r; // Radius - also size
    private java.awt.Color color;
    // Set default velocity.
    private Velocity v = new Velocity(3, 3.5);
    // Reference to a GameEnvironment
    private GameEnvironment gameEnvironment;

    /**
     * This method is a constructor of this class.
     * It defines a ball using a given point (center), radius and color.
     * @param center point of center of the circle (ball)
     * @param r radius\size of ball
     * @param color fill ball with this color
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
    }

    /**
     * This method is a constructor of this class.
     * It defines a ball using a given point (x,y), radius and color.
     * @param x x value of the center of the circle (ball)
     * @param y y value of the center of the circle (ball)
     * @param r radius\size of ball
     * @param color fill ball with this color
     */
    public Ball(double x, double y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
    }

    /**
     * This method gets the Ball to be aware of the given GameEnvironment.
     * @param gameEnvironment a GameEnvironment
     */
    public void setGameEnvironment(GameEnvironment gameEnvironment) {
        this.gameEnvironment = gameEnvironment;
    }

    /**
     * This method returns the gameEnvironment.
     * @return this.gameEnvironment
     */
    public GameEnvironment getGameEnvironment() {
        return gameEnvironment;
    }

    /**
     * Get the center of the ball.
     * @return point(x,y) which is the center of this ball
     */
    public Point getCenter() {
        return this.center;
    }

    /**
     * Get the x value of the center (point) of a ball.
     * @return x value of the center of this ball.
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * Get the y value of the center (point) of a ball.
     * @return y value of the center of this ball.
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * Get the size of a ball (radius of circle).
     * @return radius of this circle
     */
    public int getSize() {
        return this.r;
    }

    /**
     * Get the color of a ball.
     * @return color of this ball (circle)
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * Get the velocity (change in position on the `x` and the `y` axes)
     * of a ball.
     * @return velocity of this ball
     */
    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * This method is in charge of drawing a ball on a given drawing surface.
     * @param surface given DrawSurface
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(Color.BLACK);
        surface.drawCircle(this.getX(), this.getY(), this.getSize() + 1);
        surface.setColor(this.color);
        surface.fillCircle(this.getX(), this.getY(), this.getSize());
    }

    @Override
    public void timePassed() {
        this.moveOneStep();
    }

    /**
     * Set the velocity of a ball to be the given velocity.
     * @param velocity given velocity
     */
    public void setVelocity(Velocity velocity) {
        this.v = velocity;
    }

    /**
     * Set the velocity of a ball to be the given change in the position
     * on the 'x' and 'y' axes.
     * @param dx change in position on the 'x' axis
     * @param dy change in position on the 'y' axis
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * Set center of ball to the given point.
     * @param p new center of ball
     */
    public void setCenter(Point p) {
        this.center = p;
    }

    /**
     * Set center of ball to the given x and y values.
     * @param x x value of center point
     * @param y y value of center point
     */
    public void setCenter(double x, double y) {
        this.center = new Point(x, y);
    }

    /**
     * Adjust the position and speed of the ball on the 'x' axis.
     * @param x x value of the adjusted position (center).
     */
    private void adjustDx(double x) {

        // Reflect speed along normal (dx = -dx)
        this.setVelocity(-this.getVelocity().getDx(),
                this.getVelocity().getDy());

        // Re-position the ball at the edge using given x value
        this.setCenter(x, this.center.getY());
    }

    /**
     * Adjust the position and speed of the ball on the 'y' axis.
     * @param y y value of the adjusted position (center).
     */
    private void adjustDy(double y) {

        // Reflect speed along normal (dy = -dy)
        this.setVelocity(this.getVelocity().getDx(),
                -this.getVelocity().getDy());

        // Re-position the ball at the edge using given y value
        this.setCenter(this.center.getX(), y);
    }

    /**
     * This method checks if the ball crosses the left and right bounds,
     * If so, adjusts position and speed.
     * @param leftBound left bound of window/frame (may be 0).
     * @param width width of window - indicates right bound.
     */
    private void overBoundX(int leftBound, int width) {

        if (this.center.getX() + this.getVelocity().getDx()
                - this.getSize() < leftBound) {
            // Ball crosses lower bound
            adjustDx(this.getSize() + leftBound);

        } else if ((this.center.getX() + this.getVelocity().getDx())
                + this.getSize() > width + leftBound) {
            // Ball crosses upper bound
            adjustDx(width + leftBound - this.getSize());
        }
    }

    /**
     * This method checks if the ball crosses the lower and upper bounds,
     * If so, adjusts position and speed.
     * @param lowBound lower bound of window/frame (may be 0).
     * @param height height of window - indicates upper bound.
     */
    private void overBoundY(int lowBound, int height) {
        if ((this.center.getY() + this.getVelocity().getDy())
                - this.getSize() < lowBound) {

            // Ball crosses lower bound
            adjustDy(this.getSize() + lowBound);
        } else if ((this.center.getY() + this.getVelocity().getDy())
                + this.getSize() > (height + lowBound)) {

            // Ball crosses upper bound
            adjustDy(height + lowBound - this.getSize());
        }
    }

    /**
     * This method is in charge of moving the ball one step in the
     * direction defined by its velocity.
     * Lower and left bounds are set to 0.
     * @param width width of window - indicates upper bound.
     * @param height height of window - indicates right bound.
     */
    public void moveOneStep(int width, int height) {
        // Move ball one step
        this.center = this.getVelocity().applyToPoint(this.center);

        /*
        Check if the ball moves over the bounds,
        If so, adjust position the speed.
        */
        overBoundX(0, width);
        overBoundY(0, height); // May cross both x and y bounds
    }

    /**
     * This method is in charge of moving the ball one step in the
     * direction defined by its velocity.
     *
     * <p>The method computes the ball's trajectory, checks if it will hit anything,
     * and according to the hit info, the ball is moved to either the end of the trajectory,
     * or to "almost" the hit point.
     * The hit object is then notified about the hit and the velocity is updated.
     */
    public void moveOneStep() {
        // get current and next location (if no collisions occur) of ball
        Point current = this.center;
        Point next = this.getVelocity().applyToPoint(this.center);

        // get position after next one (if no collision occurs)
        Point nextNext = this.getVelocity().applyToPoint(next);

        // compute the ball trajectory
        Line trajectory = new Line(current, next);
        Line nextTrajectory = new Line(current, nextNext);

        // Check (using the game environment) if moving on this trajectory will hit anything.
        // Using nextTrajectory makes animation smoother (edges of the ball do not enter collidable objects)
        CollisionInfo hitInfo = this.gameEnvironment.getClosestCollision(nextTrajectory);

        // Get collision rectangles of paddle, and side blocks.
        Rectangle paddleRectangle = this.gameEnvironment.getCollidableList().get(0).getCollisionRectangle();
        Rectangle leftBorderRec = this.gameEnvironment.getCollidableList().get(2).getCollisionRectangle();
        Rectangle rightBorderRec = this.gameEnvironment.getCollidableList().get(3).getCollisionRectangle();

        // Check if ball is inside side blocks, if so, adjust its position.
        boolean insideLeft = isInside(current, leftBorderRec);
        boolean insideRight = isInside(current, rightBorderRec);
        if (insideLeft) {
            this.center.setX(leftBorderRec.getUpperRight().getX() + this.getSize());
        } else if (insideRight) {
            this.center.setX(rightBorderRec.getUpperLeft().getX() - this.getSize());

            // Check if ball is inside paddle, if so, adjust its position.
        } else if (isInside(current, paddleRectangle)) {

            // Check which side of edge of paddle the ball is closer to.
            if (current.distance(paddleRectangle.getUpperLeft())
                    < current.distance(paddleRectangle.getUpperRight())) {

                // ball is closer to the left, move ball to the left and above paddle
                this.center.setX(paddleRectangle.getUpperLeft().getX() - 2 * this.getSize());
                this.center.setY(paddleRectangle.getUpperLeft().getY() - 1.5 * this.getSize());

                // Adjust horizontal speed to the left (ball was hit from the right)
                this.getVelocity().setDx(-Math.abs(this.getVelocity().getDx()));

            } else {

                // ball is closer to the right, move ball to the right and above paddle
                this.center.setX(paddleRectangle.getUpperRight().getX() + 2 * this.getSize());
                this.center.setY(paddleRectangle.getUpperLeft().getY() - 1.5 * this.getSize());

                // Adjust horizontal speed to the right (ball was hit from the left)
                this.getVelocity().setDx(Math.abs(this.getVelocity().getDx()));
            }

            // Adjust vertical speed towards top (smooths animation)
            this.getVelocity().setDy(-Math.abs(this.getVelocity().getDy()));
        } else if (hitInfo == null) {

            // no hit will occur - move the ball to the end of the trajectory.
            this.center = next;
        } else {

            // hit will occur - move the ball to "almost" the hit point, but just slightly before it.
            Point almostHit = new Point(hitInfo.collisionPoint().getX() - (this.getVelocity().getDx()),
                    hitInfo.collisionPoint().getY() - (this.getVelocity().getDy()));
            this.center = almostHit;

            // notify the hit object that a collision occurred,
            // and update the velocity to the new velocity returned by the hit() method.
            Velocity newVelocity = hitInfo.collisionObject().hit(this, hitInfo.collisionPoint(), this.getVelocity());
            this.setVelocity(newVelocity);
        }
    }

    /**
     * Given a rectangle, return true if the ball is inside it.
     * @param collisionRectangle rectangle
     * @return true if ball is inside rectangle, false otherwise.
     */
    public boolean isInside(Rectangle collisionRectangle) {
        return (this.getCenter().getX() < collisionRectangle.getUpperRight().getX()
                && this.getCenter().getX() > collisionRectangle.getUpperLeft().getX()
                && this.getCenter().getY() > collisionRectangle.getUpperLeft().getY()
                && this.getCenter().getY() < collisionRectangle.getLowerLeft().getY());
    }

    /**
     * Given a point and rectangle, return true if the point is inside the rectangle.
     * @param point point
     * @param collisionRectangle rectangle
     * @return true if the point is inside rectangle, false otherwise.
     */
    public boolean isInside(Point point, Rectangle collisionRectangle) {
        return (point.getX() <= collisionRectangle.getUpperRight().getX()
                && point.getX() >= collisionRectangle.getUpperLeft().getX()
                && point.getY() >= collisionRectangle.getUpperLeft().getY()
                && point.getY() <= collisionRectangle.getLowerLeft().getY());
    }

    /**
     * This method is in charge of adding the ball to the game (calling addSprite method).
     * @param g game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * This method is in charge of removing the ball from a given game.
     * @param g game
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
    }
}
