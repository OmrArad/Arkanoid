package gui.sprites;

import biuoop.DrawSurface;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import interfaces.HitListener;
import interfaces.HitNotifier;
import interfaces.Sprite;
import interfaces.Collidable;
import gui.shapes.Rectangle;
import game.GameLevel;
import gui.shapes.Point;
import gui.Velocity;

/**
 * This class defines a block that is implementing the collidable interface,
 * as well as and other related methods.
 */
public class Block implements Collidable, Sprite, HitNotifier {

    private Rectangle shape;
    private Color color;
    private Point collision;
    private List<HitListener> hitListeners;

    /**
     * This method is the constructor.
     * @param shape rectangle shape of the block
     * @param color color of the block
     */
    public Block(Rectangle shape, Color color) {
        this.shape = shape;
        this.color = color;
        this.hitListeners = new ArrayList<HitListener>();
    }

    /**
     * This method returns the collision shape of the object it collided with.
     * @return this.shape - the shape of the block (which is a rectangle).
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.shape;
    }

    /**
     *
     * @param hitter
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }

    // Notice that we changed the hit method to include a "Ball hitter" parameter -- update the
    // Collidable interface accordingly.
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        // save point of collision (for future use maybe?)
        this.collision = collisionPoint;

        // find side of collision and update current velocity accordingly.

        if (this.shape.getRightSide().onSegment(collisionPoint)
                || this.shape.getLeftSide().onSegment(collisionPoint)) {
            currentVelocity.setDx(-currentVelocity.getDx());
        }
        if (this.shape.getUpperSide().onSegment(collisionPoint)
                || this.shape.getLowerSide().onSegment(collisionPoint)) {
            currentVelocity.setDy(-currentVelocity.getDy());
        }

        this.notifyHit(hitter);

        return currentVelocity;
    }

    /**
     * This method is in charge of calling the drawing method for block.
     * @param surface given DrawSurface
     */
    @Override
    public void drawOn(DrawSurface surface) {
        drawOnRectangle(surface, this.color, this.shape);
    }

    /**
     * This method is in charge of drawing a block on a given drawing surface,
     * with the given color and shape.
     * @param surface given Drawsurface
     * @param color color of block
     * @param shape shape of block (upper left point, width, height)
     */
    static void drawOnRectangle(DrawSurface surface, Color color, Rectangle shape) {
        surface.setColor(color);
        surface.fillRectangle((int) shape.getUpperLeft().getX(), (int) shape.getUpperLeft().getY(),
                (int) shape.getWidth(), (int) shape.getHeight());
        surface.setColor(Color.BLACK);
        surface.drawRectangle((int) shape.getUpperLeft().getX(), (int) shape.getUpperLeft().getY(),
                (int) shape.getWidth(), (int) shape.getHeight());
    }

    @Override
    public void timePassed() {
        // Currently, this method does nothing.
    }

    /**
     * This method is in charge of adding the block to the game (calling addSprite and addCollidable methods).
     * @param g game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * This method is in charge of removing the block from the game (calling removeSprite and removeCollidable methods).
     * @param gameLevel game
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeSprite(this);
        gameLevel.removeCollidable(this);
    }

    @Override
    public void addHitListener(HitListener hl) {
        hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        hitListeners.remove(hl);
    }
}
