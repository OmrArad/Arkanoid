package gui.sprites;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import java.awt.Color;
import interfaces.Sprite;
import interfaces.Collidable;
import gui.shapes.Rectangle;
import game.GameEnvironment;
import game.GameLevel;
import gui.shapes.Point;
import gui.Velocity;

/**
 * This class defines the paddle that is implementing the sprite and collidable interface,
 * as well as and other related methods.
 */
public class Paddle implements Sprite, Collidable {

    private biuoop.KeyboardSensor keyboard;
    private Rectangle shape;
    private Color color;
    private int speed;

    // Reference to a GameEnvironment
    private GameEnvironment gameEnvironment;

    private static final int ANGLE = 30; // Angle of return for paddle
//    public static final int PADDLE_SHIFT = 10; // How much to move paddle

    /**
     * This is the constructor method.
     * @param keyboard object of KeyboardSensor.
     * @param shape shape of the paddle (rectangle).
     * @param color color of the paddle (given as random color).
     * @param speed how much to move the paddle when keys are pressed.
     */
    public Paddle(KeyboardSensor keyboard, Rectangle shape, Color color, int speed) {
        this.keyboard = keyboard;
        this.shape = shape;
        this.color = color;
        this.speed = speed;
    }

    /**
     * This method is in charge of moving the paddle one step to the left.
     */
    public void moveLeft() {
        // calculate new position of x value for upper left point of paddle
        double newX = this.shape.getUpperLeft().getX() - this.speed;

        // check if paddle moves over left border block, and adjust accordingly.
        if (newX < GameLevel.SIDE_BLOCK_WIDTH) {
            newX = GameLevel.SIDE_BLOCK_WIDTH;
        }

        // set new position of paddle.
        this.shape.getUpperLeft().setX(newX);
    }

    /**
     * This method is in charge of moving the paddle one step to the right.
     */
    public void moveRight() {
        // calculate new position of x value for upper left point of paddle
        double newX = this.shape.getUpperLeft().getX() + this.speed;

        // check if paddle moves over right border block, and adjust accordingly.
        double bound = GameLevel.WIDTH - GameLevel.SIDE_BLOCK_WIDTH - this.shape.getWidth();
        if (newX > bound) {
            newX = bound;
        }

        // set new position of paddle.
        this.shape.getUpperLeft().setX(newX);
    }

    // Sprite
    @Override
    public void timePassed() {

        // check if the "left" or "right" keys are pressed, and if so move the paddle accordingly.
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            moveLeft();
        }
        if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            moveRight();
        }
    }

    @Override
    public void drawOn(DrawSurface d) {

        Block.drawOnRectangle(d, this.color, this.shape);
    }

    // Collidable
    @Override
    public Rectangle getCollisionRectangle() {
        return this.shape;
    }

    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {

        int angle;
        Velocity v;
        Point center = this.getCenter(); // center of paddle

        // distance on the x-axis from center of paddle (also x-axis).
        // positive if hit is to the right of center, and negative if hit is to the left.
        double distance = collisionPoint.getX() - center.getX();

        // divide the paddle into 5 regions,
        // but because of symmetry (we use positive/negative distance) from center of paddle,
        // divide also by 2 (therefore divide by 10)
        int regionWidth = (int) this.shape.getWidth() / 10;

        // val holds value of section with which we will calculate return angle.
        int val = (int) Math.round(distance / regionWidth);

        // if val is positive, we need to subtract 1 to make a correct calculation of value of section.
        if (val > 0) {
            val--;
        }

        // calculate value of section (-2:s1, -1:s2, 0:s3, 1:s4, 2:s5) (s stands for section)
        val = (int) Math.round((double) (val) / 2);


        // change vertical direction if hit is on upper side on the paddle
        if (this.shape.getUpperSide().onSegment(collisionPoint)) {

            // calculate return angle based on value of section
            // if distance is in 3rd(middle) sector, we only change vertical direction,
            // therefore we do not calculate velocity using angle and speed.
            // if hit is from the sides, change horizontal direction
            if (val != 0) {
                angle = ANGLE * val;
                v = Velocity.fromAngleAndSpeed(angle, currentVelocity.getSpeed());
                currentVelocity = v;
            }
            currentVelocity.setDy(-currentVelocity.getDy());
        } else if (this.shape.getRightSide().onSegment(collisionPoint)
                || this.shape.getLeftSide().onSegment(collisionPoint)) {
            currentVelocity.setDx(-currentVelocity.getDx());
        }

        // return velocity
        return currentVelocity;
    }

    /**
     * This method is in charge of adding the paddle to the game (calling addSprite and addCollidable methods).
     * @param g game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * This method gets the Paddle to be aware of the given GameEnvironment.
     * @param gameEnvironment a GameEnvironment
     */
    public void setGameEnvironment(GameEnvironment gameEnvironment) {
        this.gameEnvironment = gameEnvironment;
    }

    /**
     * Calculate and return the center of the upper side of the paddle.
     * @return center (point) of upper side of paddle.
     */
    public Point getCenter() {
        double x = this.shape.getUpperLeft().getX() + this.shape.getWidth() / 2;
        return new Point(x, this.shape.getUpperLeft().getY());
    }
}