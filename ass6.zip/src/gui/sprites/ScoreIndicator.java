package gui.sprites;

import biuoop.DrawSurface;
import game.Counter;
import game.GameLevel;
import gui.shapes.Rectangle;
import interfaces.Sprite;

import java.awt.Color;

import static gui.sprites.Block.drawOnRectangle;

/**
 * This class defines a ScoreIndicator which is in charge of indicating the game score.
 */
public class ScoreIndicator implements Sprite {

    private Counter score;
    private Color color;
    private Rectangle shape;
    private String levelName;
    private int textX;
    private int textY;
    private int textFont;

    /**
     * This is the constructor method.
     * @param score reference to score.
     * @param color color of block.
     * @param shape shape(rectangle) of block
     * @param levelName name of the level
     */
    public ScoreIndicator(Counter score, Color color, Rectangle shape, String levelName) {
        this.score = score;
        this.color = color;
        this.shape = shape;
        this.levelName = levelName;
        positionText();
    }

    /**
     * Position the text label according to the shape of the indicator.
     */
    private void positionText() {
        textX = (int) (shape.getLowerSide().middle().getX() * 0.92);
        textY = (int) (shape.getLowerLeft().getY() - 1.5);
        textFont = (int) (shape.getHeight() - 1.5);
    }

    @Override
    public void drawOn(DrawSurface d) {
        drawOnRectangle(d, this.color, this.shape);
        d.drawText(textX, textY, "Score: " + this.score.getCount(), textFont);
        d.drawText(textX + 170, textY, "Level Name: " + this.levelName, textFont);
//        d.drawText(textX - 180, textY, "Lives: ", textFont);
    }

    @Override
    public void timePassed() {
        // Currently, do nothing
    }

    /**
     * This method is in charge of adding the block to the game (calling addSprite and addCollidable methods).
     * @param g game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
