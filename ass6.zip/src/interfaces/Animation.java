package interfaces;

import biuoop.DrawSurface;

/**
 * This interface defines a list of methods for an object that is an Animation.
 */
public interface Animation {

    /**
     * This function is in charge of the logic.
     * @param d drawSurface
     */
    void doOneFrame(DrawSurface d);

    /**
     * This method is in charge of the stopping condition.
     * @return true, if should stop. false, otherwise.
     */
    boolean shouldStop();

    /**
     * This method returns milliseconds per each frame for this animation.
     * @return number of milliseconds per frame.
     */
    int getMillisecondsPerFrame();
}
