package interfaces;

import gui.shapes.Rectangle;
import gui.shapes.Point;
import gui.Velocity;
import gui.sprites.Ball;

/**
 * This interface defines a list of methods for an object that is a collidable
 * (which is an object that we can collide with).
 */
public interface Collidable {

    /**
     * This method returns the collision shape of the object it collided with.
     * @return this.shape - the shape of the block (which is a rectangle).
     */
    Rectangle getCollisionRectangle();

    /**
     * This method gets a point of collision and velocity of colliding object.
     * It returns the new velocity expected after the hit.
     * @param collisionPoint point of collision with block
     * @param currentVelocity velocity of the object that hit the block
     * @return new velocity expected after the hit.
     */
//    Velocity hit(Point collisionPoint, Velocity currentVelocity);

    /**
     * This method gets a hitter(Ball), point of collision and velocity of colliding object.
     * It notifies listeners about the hit event with the given ball,
     * and returns the new velocity expected after the hit.
     * @param hitter the ball that collided with collidable.
     * @param collisionPoint point of collision with block
     * @param currentVelocity velocity of the object that hit the block
     * @return new velocity expected after the hit.
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}
