package interfaces;
import gui.sprites.Ball;
import gui.sprites.Block;

/**
 * This interface defines a list of methods for an object that is a HitListener.
 * (which is an object that listens to objects that notify them when they are being hit).
 */
public interface HitListener {

    /**
     * This method is called whenever the beingHit object is hit.
     * @param beingHit object that is being hit.
     * @param hitter the Ball that's doing the hitting.
     */
    void hitEvent(Block beingHit, Ball hitter);
}

