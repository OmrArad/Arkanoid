package interfaces;

/**
 * This interface defines a list of methods for an object that is a HitNotifier.
 * (which is an object that notifies listeners when it is being hit).
 */
public interface HitNotifier {

    /**
     * Add hl as a listener to hit events.
     * @param hl hitListener
     */
    void addHitListener(HitListener hl);

    /**
     * Remove hl from the list of listeners to hit events.
     * @param hl hitListener
     */
    void removeHitListener(HitListener hl);
}
