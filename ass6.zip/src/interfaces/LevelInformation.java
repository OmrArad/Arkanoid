package interfaces;

import gui.Velocity;
import gui.sprites.Block;

import java.util.List;

/**
 * This interface defines a list of methods for objects that are LevelInformation.
 * (which are objects that can give information about a specific level).
 */
public interface LevelInformation {

    /**
     * Return the number of balls in this level,
     * using initialBallVelocities().size().
     *
     * @return number of balls in this level.
     */
    int numberOfBalls();

    /**
     * Return a list of the initial velocity of each ball.
     *
     * @return list of initial velocity of each ball.
     */
    List<Velocity> initialBallVelocities();

    /**
     * Return the paddle speed.
     *
     * @return paddle speed.
     */
    int paddleSpeed();

    /**
     * return the paddle width.
     *
     * @return paddle width.
     */
    int paddleWidth();

    /**
     * Return the level name,
     * which will be displayed at the top of the screen.
     *
     * @return level name.
     */
    String levelName();

    /**
     * Returns a sprite with the background of the level.
     *
     * @return background of the level.
     */
    Sprite getBackground();

    /**
     * Return a list containing The Blocks that make up this level,
     * each block contains its size, color and location.
     *
     * @return list of blocks
     */
    List<Block> blocks();

    /**
     * Return the number of blocks that should be removed
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size();
     * @return blocks.size().
     */
    int numberOfBlocksToRemove();
}