package interfaces;

import biuoop.DrawSurface;

/**
 * This interface defines a list of methods for objects that are Sprites
 * (which are game objects that can be drawn to the screen).
 */
public interface Sprite {

    /**
     * This method is in charge of drawing the sprite on a given drawing surface.
     * @param d given DrawSurface
     */
    void drawOn(DrawSurface d);

    /**
     * This method is in charge of notifying the sprite that time as passed.
     */
    void timePassed();
}
